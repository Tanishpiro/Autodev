CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  firebase_uid TEXT UNIQUE,
  role TEXT NOT NULL DEFAULT 'delivery' CHECK (role IN ('admin','manager','sales','delivery')),
  skill TEXT NOT NULL DEFAULT 'general',          -- used for team assignment (e.g. developer, designer, qa, pm)
  capacity INT NOT NULL DEFAULT 5,                -- max concurrent active tasks
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  contact_name TEXT,
  email TEXT,
  phone TEXT,
  company TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS opportunities (
  id SERIAL PRIMARY KEY,
  external_id TEXT UNIQUE,                         -- id in the external CRM (for webhook sync)
  title TEXT NOT NULL,
  customer_id INT REFERENCES customers(id),
  owner_id INT REFERENCES users(id),
  stage TEXT NOT NULL DEFAULT 'Lead' CHECK (stage IN ('Lead','Qualified','Proposal','Negotiation','Won','Lost')),
  value NUMERIC(14,2) NOT NULL DEFAULT 0,
  type TEXT NOT NULL DEFAULT 'default',            -- picks the workflow template
  scope TEXT,
  expected_close DATE,
  closed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS workflow_templates (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  opportunity_type TEXT UNIQUE NOT NULL,           -- matches opportunities.type; 'default' is the fallback
  duration_days INT NOT NULL DEFAULT 30,
  milestones JSONB NOT NULL,                       -- [{name, offset_days, role, tasks:[{title, role}]}]
  active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS projects (
  id SERIAL PRIMARY KEY,
  opportunity_id INT UNIQUE REFERENCES opportunities(id),   -- UNIQUE = idempotency: one project per won deal
  customer_id INT REFERENCES customers(id),
  name TEXT NOT NULL,
  scope TEXT,
  budget NUMERIC(14,2),
  status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','At Risk','Completed','On Hold')),
  manager_id INT REFERENCES users(id),
  start_date DATE NOT NULL,
  due_date DATE NOT NULL,
  template_id INT REFERENCES workflow_templates(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS milestones (
  id SERIAL PRIMARY KEY,
  project_id INT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  position INT NOT NULL,
  due_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','In Progress','Done','Delayed')),
  completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  project_id INT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  milestone_id INT REFERENCES milestones(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  assignee_id INT REFERENCES users(id),
  due_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'To Do' CHECK (status IN ('To Do','In Progress','Done','Blocked')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  project_id INT REFERENCES projects(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'info',
  read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  actor TEXT NOT NULL,                             -- user email, 'system' or 'webhook'
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id INT,
  details JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS webhook_subscriptions (
  id SERIAL PRIMARY KEY,
  url TEXT NOT NULL,
  events TEXT[] NOT NULL DEFAULT '{*}',
  secret TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id SERIAL PRIMARY KEY,
  subscription_id INT REFERENCES webhook_subscriptions(id) ON DELETE CASCADE,
  event TEXT NOT NULL,
  status_code INT,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assignee_id, status);
CREATE INDEX IF NOT EXISTS idx_milestones_project ON milestones(project_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
