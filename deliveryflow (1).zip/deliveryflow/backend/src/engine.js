/**
 * Delivery automation engine.
 * Trigger: opportunity -> Won.   Result: validated, idempotent project with milestones, tasks,
 * assignments, notifications, audit trail and outbound webhooks.
 */
const { tx, query, audit } = require('./db');
const { notify } = require('./notify');
const webhooks = require('./webhooks');

const addDays = (date, n) => { const d = new Date(date); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const today = () => new Date().toISOString().slice(0, 10);

/** Validate that a won opportunity has everything needed to start delivery. */
function validate(opp, customer) {
  const errors = [];
  if (!customer) errors.push('customer is missing');
  else if (!customer.name) errors.push('customer name is missing');
  if (!opp.scope || !opp.scope.trim()) errors.push('scope is empty');
  if (!(Number(opp.value) > 0)) errors.push('deal value must be greater than 0');
  return errors;
}

/** Least-loaded active user with the required skill (falls back to any delivery user). */
async function pickAssignee(client, role, loadCache) {
  const { rows } = await client.query(
    `SELECT u.id, u.capacity,
            (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id=u.id AND t.status <> 'Done') AS load
       FROM users u
      WHERE u.active AND u.role IN ('delivery','manager') AND (u.skill = $1 OR $1 = 'any')
      ORDER BY u.id`, [role]);
  let pool = rows;
  if (!pool.length) {
    pool = (await client.query(`SELECT u.id, u.capacity,
            (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id=u.id AND t.status <> 'Done') AS load
            FROM users u WHERE u.active AND u.role IN ('delivery','manager') ORDER BY u.id`)).rows;
  }
  if (!pool.length) return null;
  const scored = pool.map((u) => ({ id: u.id, util: ((+u.load) + (loadCache[u.id] || 0)) / u.capacity }));
  scored.sort((a, b) => a.util - b.util || a.id - b.id);
  loadCache[scored[0].id] = (loadCache[scored[0].id] || 0) + 1;
  return scored[0].id;
}

async function handleOpportunityWon(opportunityId, actor = 'system') {
  const result = await tx(async (client) => {
    // Lock the opportunity row so concurrent triggers serialize.
    const { rows: [opp] } = await client.query('SELECT * FROM opportunities WHERE id=$1 FOR UPDATE', [opportunityId]);
    if (!opp) throw new Error(`Opportunity ${opportunityId} not found`);
    if (opp.stage !== 'Won') return { skipped: 'not_won' };

    const { rows: [existing] } = await client.query('SELECT id FROM projects WHERE opportunity_id=$1', [opp.id]);
    if (existing) return { skipped: 'already_created', projectId: existing.id };

    const { rows: [customer] } = opp.customer_id
      ? await client.query('SELECT * FROM customers WHERE id=$1', [opp.customer_id]) : { rows: [] };

    const errors = validate(opp, customer);
    if (errors.length) {
      await audit('system', 'project.creation_failed', 'opportunity', opp.id, { errors }, client);
      const { rows: admins } = await client.query("SELECT id FROM users WHERE role IN ('admin','manager') AND active");
      for (const a of [...admins, { id: opp.owner_id }]) {
        await notify(a.id, null, `Deal "${opp.title}" is Won but can't start delivery: ${errors.join('; ')}`, 'warning', client);
      }
      return { failed: errors };
    }

    const { rows: [template] } = await client.query(
      `SELECT * FROM workflow_templates WHERE active AND opportunity_type = ANY($1) ORDER BY (opportunity_type='default') LIMIT 1`,
      [[opp.type, 'default']]);
    if (!template) throw new Error('No workflow template configured (need at least a "default")');

    const start = today();
    const due = addDays(start, template.duration_days);

    // Project manager: least-loaded manager, else any admin.
    const { rows: [pm] } = await client.query(
      `SELECT u.id FROM users u WHERE u.active AND u.role='manager'
       ORDER BY (SELECT COUNT(*) FROM projects p WHERE p.manager_id=u.id AND p.status IN ('Active','At Risk')), u.id LIMIT 1`);

    const { rows: [project] } = await client.query(
      `INSERT INTO projects(opportunity_id, customer_id, name, scope, budget, manager_id, start_date, due_date, template_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [opp.id, opp.customer_id, `${customer.name} — ${opp.title}`, opp.scope, opp.value, pm ? pm.id : null, start, due, template.id]);

    const load = {};
    const assigned = new Set();
    let taskCount = 0;
    for (const [i, m] of template.milestones.entries()) {
      const mDue = addDays(start, m.offset_days);
      const { rows: [ms] } = await client.query(
        `INSERT INTO milestones(project_id, name, position, due_date, status) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
        [project.id, m.name, i + 1, mDue, i === 0 ? 'In Progress' : 'Pending']);
      for (const t of m.tasks || []) {
        const assignee = await pickAssignee(client, t.role || m.role || 'any', load);
        await client.query(
          'INSERT INTO tasks(project_id, milestone_id, title, assignee_id, due_date) VALUES ($1,$2,$3,$4,$5)',
          [project.id, ms.id, t.title, assignee, mDue]);
        if (assignee) assigned.add(assignee);
        taskCount++;
      }
    }

    // Stakeholder notifications: PM, assignees, deal owner, admins.
    const msg = `Project "${project.name}" created from won deal (value ${opp.value}). Due ${due}.`;
    const { rows: admins } = await client.query("SELECT id FROM users WHERE role='admin' AND active");
    const recipients = new Set([pm && pm.id, opp.owner_id, ...assigned, ...admins.map((a) => a.id)].filter(Boolean));
    for (const uid of recipients) await notify(uid, project.id, msg, 'success', client);

    await audit(actor, 'project.created', 'project', project.id,
      { opportunity_id: opp.id, template: template.name, milestones: template.milestones.length, tasks: taskCount }, client);
    return { projectId: project.id, tasks: taskCount, milestones: template.milestones.length };
  });

  if (result.projectId && !result.skipped) {
    webhooks.emit('project.created', { project_id: result.projectId, opportunity_id: opportunityId })
      .catch((e) => console.error('[webhook]', e.message));
  }
  return result;
}

/** Keep milestone/project status in sync after a task changes. Returns the project's progress %. */
async function recomputeProject(projectId, actor = 'system') {
  return tx(async (client) => {
    const { rows: ms } = await client.query('SELECT id FROM milestones WHERE project_id=$1', [projectId]);
    for (const m of ms) {
      const { rows: [c] } = await client.query(
        `SELECT COUNT(*) total, COUNT(*) FILTER (WHERE status='Done') done, COUNT(*) FILTER (WHERE status='In Progress') prog
           FROM tasks WHERE milestone_id=$1`, [m.id]);
      const total = +c.total, done = +c.done;
      if (total > 0 && done === total) {
        await client.query(`UPDATE milestones SET status='Done', completed_at=COALESCE(completed_at, now()) WHERE id=$1 AND status<>'Done'`, [m.id]);
      } else {
        await client.query(
          `UPDATE milestones SET status = CASE WHEN due_date < CURRENT_DATE THEN 'Delayed' WHEN $2 > 0 OR $3 > 0 THEN 'In Progress' ELSE status END,
                  completed_at = NULL WHERE id=$1 AND status IN ('Done','Pending','In Progress','Delayed')`, [m.id, +c.prog, done]);
      }
    }
    const { rows: [p] } = await client.query(
      `SELECT (SELECT COUNT(*) FROM milestones WHERE project_id=$1) total_m,
              (SELECT COUNT(*) FROM milestones WHERE project_id=$1 AND status='Done') done_m`, [projectId]);
    if (+p.total_m > 0 && p.total_m === p.done_m) {
      const { rows: [pr] } = await client.query(
        `UPDATE projects SET status='Completed' WHERE id=$1 AND status<>'Completed' RETURNING name, manager_id`, [projectId]);
      if (pr) {
        await audit(actor, 'project.completed', 'project', projectId, {}, client);
        await notify(pr.manager_id, projectId, `Project "${pr.name}" is complete 🎉`, 'success', client);
      }
    }
  }).then(() => progress(projectId));
}

async function progress(projectId) {
  const { rows: [r] } = await query(
    `SELECT COUNT(*) total, COUNT(*) FILTER (WHERE status='Done') done FROM tasks WHERE project_id=$1`, [projectId]);
  return +r.total ? Math.round((100 * +r.done) / +r.total) : 0;
}

module.exports = { handleOpportunityWon, recomputeProject, progress, validate };
