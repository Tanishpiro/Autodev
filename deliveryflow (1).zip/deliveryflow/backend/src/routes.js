const express = require('express');
const { query, audit } = require('./db');
const { sign, hash, verifyPw, authenticate, requireRole } = require('./auth');
const crm = require('./crm');
const engine = require('./engine');
const risk = require('./risk');
const webhooks = require('./webhooks');

const router = express.Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const staff = requireRole('admin', 'manager');

/* ---------- Public ---------- */
router.get('/health', (_req, res) => res.json({ ok: true }));

router.post('/auth/login', wrap(async (req, res) => {
  const { email, password } = req.body || {};
  const { rows: [u] } = await query('SELECT * FROM users WHERE lower(email)=lower($1) AND active', [email || '']);
  if (!u || !verifyPw(password || '', u.password_hash)) return res.status(401).json({ error: 'Invalid email or password' });
  res.json({ token: sign(u), user: { id: u.id, name: u.name, email: u.email, role: u.role } });
}));

router.post('/auth/register', wrap(async (req, res) => {
  const { name, email, password, skill } = req.body || {};
  if (!name || !email || !password || password.length < 6) return res.status(400).json({ error: 'name, email and password (min 6 chars) required' });
  const { rows: [{ count }] } = await query('SELECT COUNT(*) FROM users');
  const role = +count === 0 ? 'admin' : 'delivery'; // first user becomes admin; everyone else starts as delivery
  try {
    const { rows: [u] } = await query(
      'INSERT INTO users(name,email,password_hash,role,skill) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [name, email, hash(password), role, skill || 'general']);
    await audit(email, 'user.registered', 'user', u.id, { role });
    res.status(201).json({ token: sign(u), user: { id: u.id, name: u.name, email: u.email, role: u.role } });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Email already registered' });
    throw e;
  }
}));

// Inbound CRM webhook (HMAC-verified; no JWT). Raw body captured in index.js.
router.post('/webhooks/crm', wrap(async (req, res) => {
  if (!webhooks.verifyInbound(req.rawBody ? req.rawBody.toString() : '', req.headers['x-signature']))
    return res.status(401).json({ error: 'Bad signature' });
  const out = await crm.syncFromWebhook(req.body);
  res.json({ ok: true, ...out });
}));

/* ---------- Authenticated ---------- */
router.use(authenticate);

router.get('/me', (req, res) => res.json(req.user));

router.get('/users', wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT u.id,u.name,u.email,u.role,u.skill,u.capacity,u.active,
       (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id=u.id AND t.status<>'Done')::int AS open_tasks
     FROM users u ORDER BY u.name`);
  res.json(rows);
}));
router.patch('/users/:id', requireRole('admin'), wrap(async (req, res) => {
  const { role, skill, capacity, active } = req.body;
  const { rows: [u] } = await query(
    `UPDATE users SET role=COALESCE($2,role), skill=COALESCE($3,skill), capacity=COALESCE($4,capacity), active=COALESCE($5,active)
     WHERE id=$1 RETURNING id,name,email,role,skill,capacity,active`, [req.params.id, role, skill, capacity, active]);
  await audit(req.user.email, 'user.updated', 'user', +req.params.id, req.body);
  res.json(u);
}));

/* Customers */
router.get('/customers', wrap(async (_req, res) => res.json((await query('SELECT * FROM customers ORDER BY name')).rows)));
router.post('/customers', requireRole('admin', 'manager', 'sales'), wrap(async (req, res) => {
  if (!req.body.name) return res.status(400).json({ error: 'name required' });
  const id = await crm.upsertCustomer(req.body);
  await audit(req.user.email, 'customer.saved', 'customer', id);
  res.status(201).json((await query('SELECT * FROM customers WHERE id=$1', [id])).rows[0]);
}));

/* Opportunities */
router.get('/opportunities', wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT o.*, c.name AS customer_name, u.name AS owner_name, p.id AS project_id
       FROM opportunities o LEFT JOIN customers c ON c.id=o.customer_id LEFT JOIN users u ON u.id=o.owner_id
       LEFT JOIN projects p ON p.opportunity_id=o.id ORDER BY o.created_at DESC`);
  res.json(rows);
}));
router.post('/opportunities', requireRole('admin', 'manager', 'sales'), wrap(async (req, res) => {
  const { title, customer_id, value, type, scope, expected_close } = req.body;
  if (!title) return res.status(400).json({ error: 'title required' });
  const { rows: [o] } = await query(
    `INSERT INTO opportunities(title,customer_id,owner_id,value,type,scope,expected_close) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [title, customer_id || null, req.user.id, value || 0, type || 'default', scope || null, expected_close || null]);
  await audit(req.user.email, 'opportunity.created', 'opportunity', o.id);
  res.status(201).json(o);
}));
router.patch('/opportunities/:id', requireRole('admin', 'manager', 'sales'), wrap(async (req, res) => {
  const { title, customer_id, value, type, scope, expected_close } = req.body;
  const { rows: [o] } = await query(
    `UPDATE opportunities SET title=COALESCE($2,title), customer_id=COALESCE($3,customer_id), value=COALESCE($4,value),
       type=COALESCE($5,type), scope=COALESCE($6,scope), expected_close=COALESCE($7,expected_close) WHERE id=$1 RETURNING *`,
    [req.params.id, title, customer_id, value, type, scope, expected_close]);
  if (!o) return res.status(404).json({ error: 'Not found' });
  await audit(req.user.email, 'opportunity.updated', 'opportunity', o.id, req.body);
  res.json(o);
}));
router.post('/opportunities/:id/stage', requireRole('admin', 'manager', 'sales'), wrap(async (req, res) => {
  res.json(await crm.changeStage(+req.params.id, req.body.stage, req.user.email));
}));

router.post('/opportunities/:id/retry-delivery', requireRole('admin', 'manager', 'sales'), wrap(async (req, res) => {
  await audit(req.user.email, 'opportunity.delivery_retry', 'opportunity', +req.params.id);
  res.json({ automation: await engine.handleOpportunityWon(+req.params.id, req.user.email) });
}));

/* Workflow templates */
router.get('/templates', wrap(async (_req, res) => res.json((await query('SELECT * FROM workflow_templates ORDER BY id')).rows)));
router.put('/templates/:type', requireRole('admin'), wrap(async (req, res) => {
  const { name, duration_days, milestones, active } = req.body;
  if (!Array.isArray(milestones) || !milestones.length) return res.status(400).json({ error: 'milestones[] required' });
  const { rows: [t] } = await query(
    `INSERT INTO workflow_templates(name,opportunity_type,duration_days,milestones,active) VALUES ($1,$2,$3,$4,COALESCE($5,TRUE))
     ON CONFLICT (opportunity_type) DO UPDATE SET name=EXCLUDED.name, duration_days=EXCLUDED.duration_days, milestones=EXCLUDED.milestones, active=EXCLUDED.active
     RETURNING *`,
    [name || req.params.type, req.params.type, duration_days || 30, JSON.stringify(milestones), active]);
  await audit(req.user.email, 'template.saved', 'template', t.id, { type: req.params.type });
  res.json(t);
}));

/* Projects */
router.get('/projects', wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT p.*, c.name AS customer_name, u.name AS manager_name,
       (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id)::int AS task_total,
       (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status='Done')::int AS task_done
     FROM projects p LEFT JOIN customers c ON c.id=p.customer_id LEFT JOIN users u ON u.id=p.manager_id ORDER BY p.created_at DESC`);
  res.json(rows.map((r) => ({ ...r, progress: r.task_total ? Math.round((100 * r.task_done) / r.task_total) : 0 })));
}));
router.get('/projects/:id', wrap(async (req, res) => {
  const { rows: [p] } = await query(
    `SELECT p.*, c.name AS customer_name, c.email AS customer_email, u.name AS manager_name, o.title AS deal_title
       FROM projects p LEFT JOIN customers c ON c.id=p.customer_id LEFT JOIN users u ON u.id=p.manager_id
       LEFT JOIN opportunities o ON o.id=p.opportunity_id WHERE p.id=$1`, [req.params.id]);
  if (!p) return res.status(404).json({ error: 'Not found' });
  const milestones = (await query('SELECT * FROM milestones WHERE project_id=$1 ORDER BY position', [p.id])).rows;
  const tasks = (await query(
    `SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id=t.assignee_id WHERE t.project_id=$1 ORDER BY t.id`, [p.id])).rows;
  const audits = (await query(
    `SELECT * FROM audit_logs WHERE (entity='project' AND entity_id=$1) OR (entity='task' AND (details->>'project_id')::int=$1) ORDER BY id DESC LIMIT 30`, [p.id])).rows;
  res.json({ ...p, progress: await engine.progress(p.id), milestones, tasks, audits });
}));
router.patch('/projects/:id', staff, wrap(async (req, res) => {
  const { status, manager_id } = req.body;
  const { rows: [p] } = await query(
    'UPDATE projects SET status=COALESCE($2,status), manager_id=COALESCE($3,manager_id) WHERE id=$1 RETURNING *', [req.params.id, status, manager_id]);
  await audit(req.user.email, 'project.updated', 'project', +req.params.id, req.body);
  res.json(p);
}));

/* Tasks */
router.patch('/tasks/:id', wrap(async (req, res) => {
  const { status, assignee_id } = req.body;
  const { rows: [t0] } = await query('SELECT * FROM tasks WHERE id=$1', [req.params.id]);
  if (!t0) return res.status(404).json({ error: 'Not found' });
  const isStaff = ['admin', 'manager'].includes(req.user.role);
  if (!isStaff && t0.assignee_id !== req.user.id) return res.status(403).json({ error: 'Only the assignee or a manager can update this task' });
  if (assignee_id !== undefined && !isStaff) return res.status(403).json({ error: 'Only managers can reassign tasks' });
  const { rows: [t] } = await query(
    'UPDATE tasks SET status=COALESCE($2,status), assignee_id=COALESCE($3,assignee_id) WHERE id=$1 RETURNING *', [req.params.id, status, assignee_id]);
  await audit(req.user.email, 'task.updated', 'task', t.id, { project_id: t.project_id, from: t0.status, to: t.status, assignee_id: t.assignee_id });
  const progress = await engine.recomputeProject(t.project_id, req.user.email);
  if (status === 'Blocked') {
    const { rows: [p] } = await query('SELECT name, manager_id FROM projects WHERE id=$1', [t.project_id]);
    await require('./notify').notify(p.manager_id, t.project_id, `Task "${t.title}" in "${p.name}" is Blocked`, 'warning');
  }
  res.json({ task: t, progress });
}));

/* Dashboard */
router.get('/dashboard', wrap(async (_req, res) => {
  const one = async (sql) => (await query(sql)).rows[0];
  const kpi = await one(`SELECT
      (SELECT COUNT(*) FROM opportunities WHERE stage NOT IN ('Won','Lost'))::int AS open_deals,
      (SELECT COALESCE(SUM(value),0) FROM opportunities WHERE stage NOT IN ('Won','Lost'))::float AS pipeline_value,
      (SELECT COUNT(*) FROM opportunities WHERE stage='Won')::int AS won_deals,
      (SELECT COALESCE(SUM(value),0) FROM opportunities WHERE stage='Won')::float AS won_value,
      (SELECT COUNT(*) FROM projects WHERE status='Active')::int AS active_projects,
      (SELECT COUNT(*) FROM projects WHERE status='At Risk')::int AS at_risk_projects,
      (SELECT COUNT(*) FROM projects WHERE status='Completed')::int AS completed_projects,
      (SELECT COUNT(*) FROM tasks WHERE status<>'Done' AND due_date < CURRENT_DATE)::int AS overdue_tasks,
      (SELECT COUNT(*) FROM opportunities o WHERE o.stage='Won' AND NOT EXISTS (SELECT 1 FROM projects p WHERE p.opportunity_id=o.id))::int AS won_without_project`);
  const pipeline = (await query(`SELECT stage, COUNT(*)::int AS count, COALESCE(SUM(value),0)::float AS value FROM opportunities GROUP BY stage`)).rows;
  const workload = (await query(
    `SELECT u.id, u.name, u.skill, u.capacity, COUNT(t.id) FILTER (WHERE t.status<>'Done')::int AS open_tasks
       FROM users u LEFT JOIN tasks t ON t.assignee_id=u.id WHERE u.role IN ('delivery','manager') AND u.active GROUP BY u.id ORDER BY open_tasks DESC`)).rows;
  const upcoming = (await query(
    `SELECT m.id, m.name, m.due_date, m.status, p.id AS project_id, p.name AS project_name FROM milestones m JOIN projects p ON p.id=m.project_id
      WHERE m.status<>'Done' AND p.status<>'Completed' ORDER BY m.due_date LIMIT 8`)).rows;
  res.json({ kpi, pipeline, workload, upcoming });
}));

/* Notifications (own) */
router.get('/notifications', wrap(async (req, res) => {
  res.json((await query('SELECT * FROM notifications WHERE user_id=$1 ORDER BY id DESC LIMIT 50', [req.user.id])).rows);
}));
router.post('/notifications/read', wrap(async (req, res) => {
  await query('UPDATE notifications SET read=TRUE WHERE user_id=$1', [req.user.id]);
  res.json({ ok: true });
}));

/* Audit log, risk scan, webhook subscriptions */
router.get('/audit', staff, wrap(async (_req, res) => res.json((await query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200')).rows)));
router.post('/risk/scan', staff, wrap(async (_req, res) => res.json({ flagged: await risk.scan() })));
router.get('/webhook-subscriptions', requireRole('admin'), wrap(async (_req, res) => res.json((await query('SELECT id,url,events,active FROM webhook_subscriptions')).rows)));
router.post('/webhook-subscriptions', requireRole('admin'), wrap(async (req, res) => {
  const { url, events, secret } = req.body;
  if (!/^https?:\/\//.test(url || '')) return res.status(400).json({ error: 'valid url required' });
  const { rows: [s] } = await query('INSERT INTO webhook_subscriptions(url,events,secret) VALUES ($1,$2,$3) RETURNING id,url,events,active',
    [url, events && events.length ? events : ['*'], secret || require('crypto').randomBytes(16).toString('hex')]);
  res.status(201).json(s);
}));
router.delete('/webhook-subscriptions/:id', requireRole('admin'), wrap(async (req, res) => {
  await query('DELETE FROM webhook_subscriptions WHERE id=$1', [req.params.id]); res.json({ ok: true });
}));

module.exports = router;
