const express = require('express');
const cors = require('cors');
const config = require('./config');
const db = require('./db');
const queue = require('./queue');
const risk = require('./risk');
const routes = require('./routes');

function createApp() {
  const app = express();
  app.use(cors({ origin: config.corsOrigin === '*' ? true : config.corsOrigin.split(',') }));
  // keep raw body for webhook signature verification
  app.use(express.json({ limit: '1mb', verify: (req, _res, buf) => { req.rawBody = buf; } }));
  app.use('/api', routes);
  app.use((err, _req, res, _next) => {
    if (!err.status) console.error(err);
    res.status(err.status || 500).json({ error: err.status ? err.message : 'Internal server error' });
  });
  return app;
}

async function main() {
  await db.migrate();
  await queue.init();
  risk.start(config.riskScanMinutes);
  createApp().listen(config.port, () => console.log(`DeliveryFlow API on :${config.port}`));
}

if (require.main === module) main().catch((e) => { console.error(e); process.exit(1); });
module.exports = { createApp };
