const crypto = require('crypto');
const config = require('./config');
const { query } = require('./db');

const sign = (secret, body) => crypto.createHmac('sha256', secret).update(body).digest('hex');

/** Verify inbound CRM webhook: header x-signature = hex HMAC-SHA256(rawBody, WEBHOOK_SECRET). */
function verifyInbound(rawBody, signature) {
  if (!signature) return false;
  const expected = sign(config.webhookSecret, rawBody);
  const a = Buffer.from(expected), b = Buffer.from(String(signature));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** Fire an outbound event to every matching subscription (best effort, logged). */
async function emit(event, payload) {
  const { rows } = await query(
    "SELECT * FROM webhook_subscriptions WHERE active AND ($1 = ANY(events) OR '*' = ANY(events))", [event]);
  const body = JSON.stringify({ event, payload, sent_at: new Date().toISOString() });
  await Promise.all(rows.map(async (sub) => {
    let status = null, error = null;
    try {
      const r = await fetch(sub.url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-signature': sign(sub.secret, body), 'x-event': event },
        body, signal: AbortSignal.timeout(5000),
      });
      status = r.status;
    } catch (e) { error = e.message; }
    await query('INSERT INTO webhook_deliveries(subscription_id,event,status_code,error) VALUES ($1,$2,$3,$4)',
      [sub.id, event, status, error]);
  }));
}

module.exports = { sign, verifyInbound, emit };
