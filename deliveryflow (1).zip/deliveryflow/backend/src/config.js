require('dotenv').config();
module.exports = {
  port: +process.env.PORT || 4000,
  databaseUrl: process.env.DATABASE_URL || 'postgres://crm:crm@localhost:5432/deliveryflow',
  jwtSecret: process.env.JWT_SECRET || 'dev-secret',
  redisUrl: process.env.REDIS_URL || '',
  webhookSecret: process.env.WEBHOOK_SECRET || 'dev-webhook-secret',
  firebaseProjectId: process.env.FIREBASE_PROJECT_ID || '',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  riskScanMinutes: +process.env.RISK_SCAN_MINUTES || 5,
};
