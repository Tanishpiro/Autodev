/** CRM domain logic shared by the REST API and the inbound webhook. */
const { query, audit, tx } = require('./db');
const queue = require('./queue');
const webhooks = require('./webhooks');

const STAGES = ['Lead', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];

async function changeStage(oppId, stage, actor) {
  if (!STAGES.includes(stage)) throw Object.assign(new Error(`Invalid stage: ${stage}`), { status: 400 });
  const { rows: [prev] } = await query('SELECT stage FROM opportunities WHERE id=$1', [oppId]);
  if (!prev) throw Object.assign(new Error('Opportunity not found'), { status: 404 });
  const { rows: [opp] } = await query(
    `UPDATE opportunities SET stage=$2, closed_at = CASE WHEN $2 IN ('Won','Lost') THEN now() ELSE NULL END WHERE id=$1 RETURNING *`,
    [oppId, stage]);
  await audit(actor, 'opportunity.stage_changed', 'opportunity', oppId, { from: prev.stage, to: stage });
  webhooks.emit('opportunity.stage_changed', { opportunity_id: oppId, from: prev.stage, to: stage }).catch(() => {});
  let automation = null;
  if (stage === 'Won' && prev.stage !== 'Won') automation = await queue.enqueue('opportunity.won', { opportunityId: oppId, actor });
  return { opportunity: opp, automation };
}

async function upsertCustomer(c) {
  if (!c || !c.name) return null;
  const { rows: [found] } = await query(
    'SELECT id FROM customers WHERE ($1::text IS NOT NULL AND lower(email)=lower($1)) OR lower(name)=lower($2) LIMIT 1', [c.email || null, c.name]);
  if (found) return found.id;
  const { rows: [created] } = await query(
    'INSERT INTO customers(name, contact_name, email, phone, company) VALUES ($1,$2,$3,$4,$5) RETURNING id',
    [c.name, c.contact_name || null, c.email || null, c.phone || null, c.company || null]);
  return created.id;
}

/** Inbound CRM event (Salesforce/HubSpot-style payload mapped to ours). */
async function syncFromWebhook({ event, data }) {
  if (!data || !data.id) throw Object.assign(new Error('data.id required'), { status: 400 });
  const ext = String(data.id);
  const customerId = await upsertCustomer(data.customer);
  const { rows: [owner] } = data.owner_email
    ? await query('SELECT id FROM users WHERE lower(email)=lower($1)', [data.owner_email]) : { rows: [] };
  const { rows: [existing] } = await query('SELECT id FROM opportunities WHERE external_id=$1', [ext]);
  let oppId;
  if (existing) {
    oppId = existing.id;
    await query(
      `UPDATE opportunities SET title=COALESCE($2,title), customer_id=COALESCE($3,customer_id), owner_id=COALESCE($4,owner_id),
         value=COALESCE($5,value), type=COALESCE($6,type), scope=COALESCE($7,scope), expected_close=COALESCE($8,expected_close) WHERE id=$1`,
      [oppId, data.title, customerId, owner && owner.id, data.value, data.type, data.scope, data.expected_close]);
  } else {
    const { rows: [o] } = await query(
      `INSERT INTO opportunities(external_id,title,customer_id,owner_id,value,type,scope,expected_close)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [ext, data.title || `CRM deal ${ext}`, customerId, owner && owner.id, data.value || 0, data.type || 'default', data.scope, data.expected_close]);
    oppId = o.id;
    await audit('webhook', 'opportunity.synced', 'opportunity', oppId, { external_id: ext });
  }
  if (data.stage) return changeStage(oppId, data.stage, 'webhook');
  return { opportunity: { id: oppId } };
}

module.exports = { STAGES, changeStage, syncFromWebhook, upsertCustomer };
