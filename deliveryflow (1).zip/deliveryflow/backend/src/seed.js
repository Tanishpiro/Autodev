/** Seeds demo users, templates, customers and deals. Safe to re-run. */
const db = require('./db');
const { hash } = require('./auth');

const TEMPLATES = [
  { type: 'default', name: 'Standard Delivery', days: 30, milestones: [
    { name: 'Kickoff & Planning', offset_days: 3, tasks: [{ title: 'Kickoff call with customer', role: 'pm' }, { title: 'Confirm scope & success criteria', role: 'pm' }] },
    { name: 'Execution', offset_days: 20, tasks: [{ title: 'Build / configure solution', role: 'developer' }, { title: 'Weekly status update', role: 'pm' }] },
    { name: 'Review & Handover', offset_days: 30, tasks: [{ title: 'QA and acceptance testing', role: 'qa' }, { title: 'Customer sign-off & handover', role: 'pm' }] } ] },
  { type: 'software', name: 'Software Implementation', days: 60, milestones: [
    { name: 'Discovery', offset_days: 7, tasks: [{ title: 'Requirements workshop', role: 'pm' }, { title: 'Technical architecture', role: 'developer' }] },
    { name: 'Design', offset_days: 18, tasks: [{ title: 'UX wireframes', role: 'designer' }, { title: 'Data model & API contract', role: 'developer' }] },
    { name: 'Development', offset_days: 42, tasks: [{ title: 'Backend implementation', role: 'developer' }, { title: 'Frontend implementation', role: 'developer' }, { title: 'Integration with customer systems', role: 'developer' }] },
    { name: 'Testing & UAT', offset_days: 54, tasks: [{ title: 'Test plan & execution', role: 'qa' }, { title: 'User acceptance testing', role: 'pm' }] },
    { name: 'Go-live', offset_days: 60, tasks: [{ title: 'Production deployment', role: 'developer' }, { title: 'Training & handover', role: 'pm' }] } ] },
  { type: 'consulting', name: 'Consulting Engagement', days: 45, milestones: [
    { name: 'Assessment', offset_days: 10, tasks: [{ title: 'Stakeholder interviews', role: 'pm' }, { title: 'Current-state analysis', role: 'analyst' }] },
    { name: 'Recommendations', offset_days: 30, tasks: [{ title: 'Draft recommendations report', role: 'analyst' }, { title: 'Review with leadership', role: 'pm' }] },
    { name: 'Final Delivery', offset_days: 45, tasks: [{ title: 'Final presentation', role: 'pm' }] } ] },
];

async function seed() {
  await db.migrate();
  const users = [
    ['Admin User', 'admin@demo.com', 'admin', 'general', 8], ['Maya Manager', 'manager@demo.com', 'manager', 'pm', 6],
    ['Sam Sales', 'sales@demo.com', 'sales', 'general', 5], ['Dev Developer', 'dev1@demo.com', 'delivery', 'developer', 5],
    ['Dina Developer', 'dev2@demo.com', 'delivery', 'developer', 5], ['Quinn QA', 'qa@demo.com', 'delivery', 'qa', 5],
    ['Dani Designer', 'design@demo.com', 'delivery', 'designer', 5], ['Anil Analyst', 'analyst@demo.com', 'delivery', 'analyst', 5],
    ['Priya PM', 'pm@demo.com', 'delivery', 'pm', 6],
  ];
  for (const [name, email, role, skill, cap] of users)
    await db.query(`INSERT INTO users(name,email,password_hash,role,skill,capacity) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (email) DO NOTHING`,
      [name, email, hash('password123'), role, skill, cap]);
  for (const t of TEMPLATES)
    await db.query(`INSERT INTO workflow_templates(name,opportunity_type,duration_days,milestones) VALUES ($1,$2,$3,$4)
                    ON CONFLICT (opportunity_type) DO NOTHING`, [t.name, t.type, t.days, JSON.stringify(t.milestones)]);
  const { rows: [{ count }] } = await db.query('SELECT COUNT(*) FROM opportunities');
  if (+count === 0) {
    const { rows: [sales] } = await db.query("SELECT id FROM users WHERE email='sales@demo.com'");
    const custs = [['Acme Corp', 'Jane Doe', 'jane@acme.com'], ['Globex Ltd', 'Hank Scorpio', 'hank@globex.com'], ['Initech', 'Bill Lumbergh', 'bill@initech.com']];
    const ids = [];
    for (const [name, contact, email] of custs)
      ids.push((await db.query('INSERT INTO customers(name,contact_name,email) VALUES ($1,$2,$3) RETURNING id', [name, contact, email])).rows[0].id);
    const deals = [
      ['Customer Portal Build', ids[0], 'Proposal', 48000, 'software', 'Customer self-service portal with SSO and billing integration'],
      ['Process Audit', ids[1], 'Negotiation', 15000, 'consulting', 'Operational audit of logistics workflows'],
      ['Support Retainer', ids[2], 'Qualified', 9000, 'default', 'Quarterly support and maintenance retainer'],
    ];
    for (const [title, cid, stage, value, type, scope] of deals)
      await db.query('INSERT INTO opportunities(title,customer_id,owner_id,stage,value,type,scope,expected_close) VALUES ($1,$2,$3,$4,$5,$6,$7,CURRENT_DATE + 14)',
        [title, cid, sales.id, stage, value, type, scope]);
  }
  console.log('Seed complete. Login: admin@demo.com / manager@demo.com / sales@demo.com / dev1@demo.com — password: password123');
}

if (require.main === module) seed().then(() => db.pool.end()).catch((e) => { console.error(e); process.exit(1); });
module.exports = { seed };
