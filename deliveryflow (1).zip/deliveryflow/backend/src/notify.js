const { query } = require('./db');

/** In-app notification (client optional so it can join a transaction). */
async function notify(userId, projectId, message, level = 'info', client = null) {
  if (!userId) return;
  await (client || { query }).query(
    'INSERT INTO notifications(user_id, project_id, message, level) VALUES ($1,$2,$3,$4)',
    [userId, projectId, message, level]);
}

module.exports = { notify };
