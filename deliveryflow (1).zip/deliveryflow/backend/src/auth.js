const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('./config');
const { query } = require('./db');

let firebaseAuth = null;
if (config.firebaseProjectId) {
  try {
    const admin = require('firebase-admin');
    admin.initializeApp({ projectId: config.firebaseProjectId });
    firebaseAuth = admin.auth();
    console.log('[auth] Firebase token verification enabled');
  } catch (e) {
    console.warn('[auth] firebase-admin unavailable, using local JWT only:', e.message);
  }
}

const sign = (u) => jwt.sign({ id: u.id, email: u.email, role: u.role, name: u.name }, config.jwtSecret, { expiresIn: '12h' });
const hash = (pw) => bcrypt.hashSync(pw, 10);
const verifyPw = (pw, h) => !!h && bcrypt.compareSync(pw, h);

/** Express middleware: accepts our own JWT or (optionally) a Firebase ID token. */
async function authenticate(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    req.user = jwt.verify(token, config.jwtSecret);
    return next();
  } catch (_) { /* fall through to Firebase */ }
  if (firebaseAuth) {
    try {
      const decoded = await firebaseAuth.verifyIdToken(token);
      const { rows } = await query('SELECT * FROM users WHERE firebase_uid=$1 OR email=$2', [decoded.uid, decoded.email]);
      if (rows[0]) { req.user = { id: rows[0].id, email: rows[0].email, role: rows[0].role, name: rows[0].name }; return next(); }
    } catch (_) { /* invalid */ }
  }
  res.status(401).json({ error: 'Invalid token' });
}

/** Role guard: requireRole('admin','manager') */
const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ error: `Requires role: ${roles.join(' or ')}` });

module.exports = { sign, hash, verifyPw, authenticate, requireRole };
