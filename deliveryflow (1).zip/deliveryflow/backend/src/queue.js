/**
 * Event queue. With REDIS_URL set, jobs go through BullMQ (retries, backoff, durability).
 * Without it, jobs run in-process so the project works with only PostgreSQL.
 */
const config = require('./config');
const engine = require('./engine');

let bull = null;

const handlers = {
  'opportunity.won': (data) => engine.handleOpportunityWon(data.opportunityId, data.actor),
};

async function init() {
  if (!config.redisUrl) { console.log('[queue] REDIS_URL not set → in-process mode'); return; }
  const { Queue, Worker } = require('bullmq');
  const IORedis = require('ioredis');
  const connection = new IORedis(config.redisUrl, { maxRetriesPerRequest: null, lazyConnect: true, retryStrategy: () => null });
  try { await connection.connect(); } catch (e) { console.warn('[queue] Redis unreachable → in-process mode'); connection.disconnect(); return; }
  const queue = new Queue('delivery-events', { connection });
  new Worker('delivery-events', async (job) => handlers[job.name](job.data), { connection, concurrency: 5 })
    .on('failed', (job, err) => console.error(`[queue] job ${job && job.name} failed:`, err.message));
  bull = queue;
  console.log('[queue] BullMQ enabled');
}

async function enqueue(name, data) {
  if (bull) {
    await bull.add(name, data, { attempts: 3, backoff: { type: 'exponential', delay: 2000 }, removeOnComplete: 1000 });
    return { queued: true };
  }
  return handlers[name](data);
}

module.exports = { init, enqueue };
