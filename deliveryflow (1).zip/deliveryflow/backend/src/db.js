const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const config = require('./config');

const pool = new Pool({ connectionString: config.databaseUrl });

const query = (text, params) => pool.query(text, params);

/** Run fn(client) inside a transaction. */
async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

async function migrate() {
  await pool.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
}

/** Write an audit entry (pass a client to make it part of a transaction). */
async function audit(actor, action, entity, entityId, details = {}, client = pool) {
  await client.query(
    'INSERT INTO audit_logs(actor, action, entity, entity_id, details) VALUES ($1,$2,$3,$4,$5)',
    [actor, action, entity, entityId, JSON.stringify(details)]
  );
}

module.exports = { pool, query, tx, migrate, audit };
