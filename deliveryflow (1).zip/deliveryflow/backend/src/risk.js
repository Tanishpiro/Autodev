/** Risk scanner: flags overdue milestones/tasks and projects trending late. Idempotent; safe to run often. */
const { query, audit, tx } = require('./db');
const { notify } = require('./notify');
const webhooks = require('./webhooks');

async function scan() {
  const flagged = [];
  const { rows: projects } = await query(
    `SELECT p.id, p.name, p.status, p.manager_id, p.due_date,
       (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status<>'Done' AND t.due_date < CURRENT_DATE) overdue_tasks,
       (SELECT COUNT(*) FROM milestones m WHERE m.project_id=p.id AND m.status<>'Done' AND m.due_date < CURRENT_DATE) overdue_ms,
       (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.status='Blocked') blocked
     FROM projects p WHERE p.status IN ('Active','At Risk')`);
  for (const p of projects) {
    const reasons = [];
    if (+p.overdue_ms) reasons.push(`${p.overdue_ms} overdue milestone(s)`);
    if (+p.overdue_tasks) reasons.push(`${p.overdue_tasks} overdue task(s)`);
    if (+p.blocked) reasons.push(`${p.blocked} blocked task(s)`);
    const atRisk = reasons.length > 0;
    if (atRisk && p.status === 'Active') {
      await tx(async (c) => {
        await c.query("UPDATE projects SET status='At Risk' WHERE id=$1", [p.id]);
        await c.query(`UPDATE milestones SET status='Delayed' WHERE project_id=$1 AND status IN ('Pending','In Progress') AND due_date < CURRENT_DATE`, [p.id]);
        await audit('system', 'project.flagged_at_risk', 'project', p.id, { reasons }, c);
        await notify(p.manager_id, p.id, `"${p.name}" is At Risk: ${reasons.join(', ')}`, 'danger', c);
      });
      webhooks.emit('project.at_risk', { project_id: p.id, reasons }).catch(() => {});
      flagged.push({ id: p.id, reasons });
    } else if (!atRisk && p.status === 'At Risk') {
      await query("UPDATE projects SET status='Active' WHERE id=$1", [p.id]);
      await audit('system', 'project.recovered', 'project', p.id, {});
    }
  }
  return flagged;
}

function start(minutes) {
  const t = setInterval(() => scan().catch((e) => console.error('[risk]', e.message)), minutes * 60 * 1000);
  t.unref();
  return t;
}

module.exports = { scan, start };
