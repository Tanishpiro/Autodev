process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgres://crm:crm@localhost:5432/deliveryflow_test';
process.env.REDIS_URL = ''; // in-process queue for deterministic tests
process.env.WEBHOOK_SECRET = 'testsecret';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const db = require('../src/db');
const { seed } = require('../src/seed');
const { createApp } = require('../src/index');
const { sign } = require('../src/webhooks');

let server, base;
const api = async (path, { method = 'GET', body, token, raw, headers = {} } = {}) => {
  const r = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token && { authorization: `Bearer ${token}` }), ...headers }, body: raw || (body && JSON.stringify(body)) });
  return { status: r.status, data: await r.json().catch(() => null) };
};
const login = async (email) => (await api('/api/auth/login', { method: 'POST', body: { email, password: 'password123' } })).data.token;

before(async () => {
  await db.migrate();
  await db.query('TRUNCATE users, customers, opportunities, workflow_templates, projects, milestones, tasks, notifications, audit_logs, webhook_subscriptions, webhook_deliveries RESTART IDENTITY CASCADE');
  await seed();
  server = createApp().listen(0);
  base = `http://localhost:${server.address().port}`;
});
after(async () => { server.close(); await db.pool.end(); });

test('auth: rejects bad login and unauthenticated calls', async () => {
  assert.equal((await api('/api/auth/login', { method: 'POST', body: { email: 'admin@demo.com', password: 'nope' } })).status, 401);
  assert.equal((await api('/api/projects')).status, 401);
});

test('Won opportunity auto-creates project, milestones, tasks, assignments, notifications; idempotent', async () => {
  const sales = await login('sales@demo.com'), mgr = await login('manager@demo.com');
  const { data: opps } = await api('/api/opportunities', { token: sales });
  const deal = opps.find((o) => o.type === 'software');
  const r = await api(`/api/opportunities/${deal.id}/stage`, { method: 'POST', token: sales, body: { stage: 'Won' } });
  assert.equal(r.status, 200);
  assert.ok(r.data.automation.projectId);
  const { data: p } = await api(`/api/projects/${r.data.automation.projectId}`, { token: mgr });
  assert.equal(p.milestones.length, 5);
  assert.equal(p.tasks.length, 11);
  assert.ok(p.tasks.every((t) => t.assignee_id), 'every task assigned');
  assert.equal(p.name, 'Acme Corp — Customer Portal Build');
  assert.equal(p.scope, deal.scope);
  const devTasks = p.tasks.filter((t) => /implementation|Integration|architecture|API|deployment/i.test(t.title));
  assert.ok(devTasks.every((t) => /Dev|Dina/.test(t.assignee_name)), 'developer tasks go to developers');
  const names = new Set(devTasks.map((t) => t.assignee_name));
  assert.equal(names.size, 2, 'load is balanced across both developers');
  const { data: notes } = await api('/api/notifications', { token: mgr });
  assert.ok(notes.some((n) => n.project_id === p.id));
  // re-trigger directly: must not create a duplicate
  const engine = require('../src/engine');
  const again = await engine.handleOpportunityWon(deal.id);
  assert.equal(again.skipped, 'already_created');
  assert.equal((await db.query('SELECT COUNT(*)::int c FROM projects')).rows[0].c, 1);
});

test('validation blocks project creation when scope is missing and alerts managers', async () => {
  const sales = await login('sales@demo.com'), mgr = await login('manager@demo.com');
  const { data: opp } = await api('/api/opportunities', { method: 'POST', token: sales, body: { title: 'No scope deal', customer_id: 1, value: 1000 } });
  const r = await api(`/api/opportunities/${opp.id}/stage`, { method: 'POST', token: sales, body: { stage: 'Won' } });
  assert.deepEqual(r.data.automation.failed, ['scope is empty']);
  const { data: notes } = await api('/api/notifications', { token: mgr });
  assert.ok(notes.some((n) => /can't start delivery/.test(n.message)));
});

test('role guard: delivery user cannot change deal stage', async () => {
  const dev = await login('dev1@demo.com');
  assert.equal((await api('/api/opportunities/1/stage', { method: 'POST', token: dev, body: { stage: 'Lost' } })).status, 403);
});

test('inbound CRM webhook: signature enforced, creates deal and triggers project on Won', async () => {
  const body = JSON.stringify({ event: 'opportunity.updated', data: { id: 'SF-001', title: 'Webhook Deal', stage: 'Won', value: 20000, type: 'consulting', scope: 'Market study',
    customer: { name: 'Umbrella Inc', email: 'ops@umbrella.com' }, owner_email: 'sales@demo.com' } });
  assert.equal((await api('/api/webhooks/crm', { method: 'POST', raw: body, headers: { 'x-signature': 'bad' } })).status, 401);
  const ok = await api('/api/webhooks/crm', { method: 'POST', raw: body, headers: { 'x-signature': sign('testsecret', body) } });
  assert.equal(ok.status, 200);
  assert.ok(ok.data.automation.projectId);
  // replaying the same event is harmless
  const replay = await api('/api/webhooks/crm', { method: 'POST', raw: body, headers: { 'x-signature': sign('testsecret', body) } });
  assert.equal(replay.status, 200);
  assert.equal((await db.query("SELECT COUNT(*)::int c FROM projects WHERE name LIKE 'Umbrella%'")).rows[0].c, 1);
});

test('task updates drive milestone + project progress and completion', async () => {
  const mgr = await login('manager@demo.com');
  const { data: projects } = await api('/api/projects', { token: mgr });
  const p = projects.find((x) => x.name.startsWith('Umbrella'));
  const { data: full } = await api(`/api/projects/${p.id}`, { token: mgr });
  let last;
  for (const t of full.tasks) last = await api(`/api/tasks/${t.id}`, { method: 'PATCH', token: mgr, body: { status: 'Done' } });
  assert.equal(last.data.progress, 100);
  const { data: done } = await api(`/api/projects/${p.id}`, { token: mgr });
  assert.equal(done.status, 'Completed');
  assert.ok(done.milestones.every((m) => m.status === 'Done'));
});

test('assignee-only task permissions', async () => {
  const mgr = await login('manager@demo.com'), qa = await login('qa@demo.com');
  const { data: projects } = await api('/api/projects', { token: mgr });
  const { data: full } = await api(`/api/projects/${projects.find((x) => x.name.startsWith('Acme')).id}`, { token: mgr });
  const notQa = full.tasks.find((t) => t.assignee_name !== 'Quinn QA');
  assert.equal((await api(`/api/tasks/${notQa.id}`, { method: 'PATCH', token: qa, body: { status: 'Done' } })).status, 403);
  const mine = full.tasks.find((t) => t.assignee_name === 'Quinn QA');
  assert.equal((await api(`/api/tasks/${mine.id}`, { method: 'PATCH', token: qa, body: { status: 'In Progress' } })).status, 200);
});

test('risk scan flags overdue work as At Risk and notifies the manager', async () => {
  const mgr = await login('manager@demo.com');
  const { data: projects } = await api('/api/projects', { token: mgr });
  const acme = projects.find((x) => x.name.startsWith('Acme'));
  await db.query("UPDATE tasks SET due_date = CURRENT_DATE - 3 WHERE project_id=$1 AND id = (SELECT MIN(id) FROM tasks WHERE project_id=$1)", [acme.id]);
  const r = await api('/api/risk/scan', { method: 'POST', token: mgr });
  assert.equal(r.data.flagged.length, 1);
  assert.equal((await api(`/api/projects/${acme.id}`, { token: mgr })).data.status, 'At Risk');
  const { data: notes } = await api('/api/notifications', { token: mgr });
  assert.ok(notes.some((n) => /At Risk/.test(n.message)));
  assert.equal((await api('/api/risk/scan', { method: 'POST', token: mgr })).data.flagged.length, 0, 'scan is idempotent');
});

test('dashboard and audit log reflect activity', async () => {
  const mgr = await login('manager@demo.com');
  const { data: d } = await api('/api/dashboard', { token: mgr });
  assert.equal(d.kpi.won_deals, 3);
  assert.equal(d.kpi.won_without_project, 1, "the scope-less deal is surfaced on the dashboard");
  assert.equal(d.kpi.at_risk_projects, 1);
  const { data: a } = await api('/api/audit', { token: mgr });
  for (const act of ['project.created', 'project.creation_failed', 'project.flagged_at_risk', 'opportunity.stage_changed'])
    assert.ok(a.some((x) => x.action === act), `audit has ${act}`);
});
