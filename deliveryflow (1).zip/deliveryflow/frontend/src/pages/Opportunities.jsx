import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, money, fmtDate } from '../api.js';
import { useApp } from '../App.jsx';

const STAGES = ['Lead', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
const blank = { title: '', customer_id: '', newCustomer: '', value: '', type: 'default', scope: '', expected_close: '' };

export default function Opportunities() {
  const { notify, user } = useApp();
  const [opps, setOpps] = useState([]); const [custs, setCusts] = useState([]); const [types, setTypes] = useState(['default']);
  const [f, setF] = useState(blank); const [show, setShow] = useState(false);
  const canEdit = ['admin', 'manager', 'sales'].includes(user.role);
  const load = () => Promise.all([api('/opportunities'), api('/customers'), api('/templates')]).then(([o, c, t]) => { setOpps(o); setCusts(c); setTypes(t.map((x) => x.opportunity_type)); });
  useEffect(() => { load(); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const create = async (e) => {
    e.preventDefault();
    try {
      let cid = f.customer_id;
      if (!cid && f.newCustomer) cid = (await api('/customers', { method: 'POST', body: { name: f.newCustomer } })).id;
      await api('/opportunities', { method: 'POST', body: { ...f, customer_id: cid || null, value: +f.value || 0, expected_close: f.expected_close || null } });
      setF(blank); setShow(false); notify('Deal created'); load();
    } catch (x) { notify(x.message, true); }
  };
  const move = async (o, stage) => {
    try {
      const r = await api(`/opportunities/${o.id}/stage`, { method: 'POST', body: { stage } });
      const a = r.automation;
      if (a && a.queued) { notify('⚙️ Automation queued — project is being created…'); setTimeout(load, 1500); return; }
      if (a && a.projectId) notify(`🚀 Project created automatically: ${a.milestones} milestones, ${a.tasks} tasks assigned.`);
      else if (a && a.failed) notify(`Deal won, but project not created: ${a.failed.join('; ')}`, true);
      else notify(`Moved to ${stage}`);
      load();
    } catch (x) { notify(x.message, true); }
  };

  const fixAndRetry = async (o) => {
    const scope = window.prompt('Enter the missing project scope for this deal:', o.scope || '');
    if (!scope) return;
    try {
      await api(`/opportunities/${o.id}`, { method: 'PATCH', body: { scope } });
      const r = await api(`/opportunities/${o.id}/retry-delivery`, { method: 'POST' });
      if (r.automation.projectId) notify('🚀 Project created automatically.'); else notify((r.automation.failed || ['Could not create project']).join('; '), true);
      load();
    } catch (x) { notify(x.message, true); }
  };

  return (
    <>
      <div className="between"><div><h1>Deals (CRM)</h1><p className="sub">Moving a deal to <b>Won</b> triggers the delivery automation engine.</p></div>
        {canEdit && <button onClick={() => setShow(!show)}>{show ? 'Cancel' : '+ New deal'}</button>}</div>
      {show && <form className="card" onSubmit={create}>
        <div className="grid g3">
          <div><label>Title</label><input value={f.title} onChange={set('title')} required /></div>
          <div><label>Customer</label><select value={f.customer_id} onChange={set('customer_id')}><option value="">— new customer below —</option>{custs.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
          <div><label>…or new customer name</label><input value={f.newCustomer} onChange={set('newCustomer')} disabled={!!f.customer_id} /></div>
          <div><label>Value (USD)</label><input type="number" min="0" value={f.value} onChange={set('value')} /></div>
          <div><label>Workflow template</label><select value={f.type} onChange={set('type')}>{types.map((t) => <option key={t}>{t}</option>)}</select></div>
          <div><label>Expected close</label><input type="date" value={f.expected_close} onChange={set('expected_close')} /></div>
        </div>
        <label>Scope (required to start delivery)</label><textarea rows={2} value={f.scope} onChange={set('scope')} />
        <p><button>Create deal</button></p></form>}
      <div className="card"><table><thead><tr><th>Deal</th><th>Customer</th><th>Value</th><th>Template</th><th>Expected close</th><th>Stage</th><th>Delivery</th></tr></thead><tbody>
        {opps.map((o) => <tr key={o.id}><td><b>{o.title}</b><div className="muted small">{o.owner_name}</div></td><td>{o.customer_name || '—'}</td><td>{money(o.value)}</td><td>{o.type}</td><td>{fmtDate(o.expected_close)}</td>
          <td>{canEdit && !o.project_id ? <select value={o.stage} onChange={(e) => move(o, e.target.value)} style={{ width: 130 }}>{STAGES.map((s) => <option key={s}>{s}</option>)}</select> : <span className={`badge b-${o.stage}`}>{o.stage}</span>}</td>
          <td>{o.project_id ? <Link to={`/projects/${o.project_id}`}>View project →</Link> : o.stage === 'Won' ? <>{canEdit ? <button className="sm ghost" onClick={() => fixAndRetry(o)}>Fix data &amp; retry</button> : <span className="badge b-warning">Needs data</span>}</> : <span className="muted">—</span>}</td></tr>)}
        {opps.length === 0 && <tr><td colSpan={7} className="muted">No deals yet.</td></tr>}
      </tbody></table></div>
    </>
  );
}
