import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, money, fmtDate } from '../api.js';

const STAGES = ['Lead', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
const Kpi = ({ l, v, sub }) => <div className="card kpi"><div className="l">{l}</div><div className="v">{v}</div><div className="muted small">{sub}</div></div>;

export default function Dashboard() {
  const [d, setD] = useState(null);
  useEffect(() => { api('/dashboard').then(setD); }, []);
  if (!d) return <p>Loading…</p>;
  const { kpi, pipeline, workload, upcoming } = d;
  const maxV = Math.max(1, ...pipeline.map((p) => p.value));
  return (
    <>
      <h1>Dashboard</h1><p className="sub">One view for sales, delivery and management.</p>
      {kpi.won_without_project > 0 && <div className="hint">⚠️ {kpi.won_without_project} won deal(s) have no project — check data validation in <Link to="/opportunities">Deals</Link>.</div>}
      <div className="grid g4">
        <Kpi l="Open pipeline" v={money(kpi.pipeline_value)} sub={`${kpi.open_deals} open deals`} />
        <Kpi l="Won revenue" v={money(kpi.won_value)} sub={`${kpi.won_deals} deals won`} />
        <Kpi l="Active projects" v={kpi.active_projects} sub={`${kpi.completed_projects} completed`} />
        <Kpi l="At-risk projects" v={kpi.at_risk_projects} sub={`${kpi.overdue_tasks} overdue tasks`} />
      </div>
      <div className="grid g2">
        <div className="card"><h2>Sales pipeline</h2>
          {STAGES.map((s) => { const p = pipeline.find((x) => x.stage === s) || { count: 0, value: 0 };
            return <div key={s} style={{ marginBottom: 10 }}><div className="between small"><span>{s} · {p.count}</span><span>{money(p.value)}</span></div>
              <div className={`bar ${s === 'Won' ? 'ok' : s === 'Lost' ? 'bad' : ''}`}><i style={{ width: `${(100 * p.value) / maxV}%` }} /></div></div>; })}
        </div>
        <div className="card"><h2>Team workload</h2>
          {workload.map((w) => <div key={w.id} style={{ marginBottom: 10 }}><div className="between small"><span>{w.name} <span className="muted">({w.skill})</span></span><span>{w.open_tasks}/{w.capacity}</span></div>
            <div className={`bar ${w.open_tasks > w.capacity ? 'bad' : ''}`}><i style={{ width: `${Math.min(100, (100 * w.open_tasks) / w.capacity)}%` }} /></div></div>)}
        </div>
      </div>
      <div className="card"><h2>Upcoming milestones</h2>
        {upcoming.length === 0 ? <p className="muted">No active milestones yet. Mark a deal as Won to auto-create a project.</p> :
          <table><thead><tr><th>Milestone</th><th>Project</th><th>Due</th><th>Status</th></tr></thead><tbody>
            {upcoming.map((m) => <tr key={m.id}><td>{m.name}</td><td><Link to={`/projects/${m.project_id}`}>{m.project_name}</Link></td><td>{fmtDate(m.due_date)}</td><td><span className={`badge b-${m.status}`}>{m.status}</span></td></tr>)}
          </tbody></table>}
      </div>
    </>
  );
}
