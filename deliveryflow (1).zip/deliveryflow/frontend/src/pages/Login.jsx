import React, { useState } from 'react';
import { api } from '../api.js';
import { useApp } from '../App.jsx';

const DEMO = [['admin@demo.com', 'Admin'], ['manager@demo.com', 'Manager'], ['sales@demo.com', 'Sales'], ['dev1@demo.com', 'Developer']];

export default function Login() {
  const { login } = useApp();
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ name: '', email: '', password: '', skill: 'developer' });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setErr('');
    try { const r = await api(mode === 'login' ? '/auth/login' : '/auth/register', { method: 'POST', body: f }); login(r.token, r.user); }
    catch (x) { setErr(x.message); }
  };
  return (
    <div className="login card">
      <h1>⚡ DeliveryFlow</h1>
      <p className="sub">CRM → project delivery automation</p>
      <form onSubmit={submit}>
        {mode === 'register' && <><label>Name</label><input value={f.name} onChange={set('name')} required />
          <label>Skill</label><select value={f.skill} onChange={set('skill')}>{['developer', 'designer', 'qa', 'pm', 'analyst', 'general'].map((s) => <option key={s}>{s}</option>)}</select></>}
        <label>Email</label><input type="email" value={f.email} onChange={set('email')} required />
        <label>Password</label><input type="password" value={f.password} onChange={set('password')} required minLength={6} />
        {err && <div className="err">{err}</div>}
        <p><button style={{ width: '100%' }}>{mode === 'login' ? 'Sign in' : 'Create account'}</button></p>
      </form>
      <p className="small muted">{mode === 'login' ? 'No account? ' : 'Have an account? '}
        <a href="#" onClick={(e) => { e.preventDefault(); setMode(mode === 'login' ? 'register' : 'login'); }}>{mode === 'login' ? 'Register' : 'Sign in'}</a></p>
      {mode === 'login' && <p className="small muted demo">Demo (password123):<br />{DEMO.map(([em, l]) => <span key={em} onClick={() => setF({ ...f, email: em, password: 'password123' })}>{l}</span>)}</p>}
    </div>
  );
}
