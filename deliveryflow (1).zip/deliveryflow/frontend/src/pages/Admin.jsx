import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, fmtTime } from '../api.js';
import { useApp } from '../App.jsx';

export function Notifications() {
  const { setUnread } = useApp();
  const [n, setN] = useState([]);
  useEffect(() => { api('/notifications').then(setN); }, []);
  const readAll = async () => { await api('/notifications/read', { method: 'POST' }); setUnread(0); setN(n.map((x) => ({ ...x, read: true }))); };
  return (<><div className="between"><h1>Notifications</h1><button className="ghost" onClick={readAll}>Mark all read</button></div>
    <div className="card" style={{ padding: 0 }}>{n.length === 0 && <p className="muted" style={{ padding: 18 }}>You're all caught up.</p>}
      {n.map((x) => <div key={x.id} className={`note ${x.read ? '' : 'unread'}`}><span className={`badge b-${x.level}`}>{x.level}</span> {x.project_id ? <Link to={`/projects/${x.project_id}`}>{x.message}</Link> : x.message}<div className="muted small">{fmtTime(x.created_at)}</div></div>)}</div></>);
}

export function Audit() {
  const [a, setA] = useState([]); const { notify } = useApp();
  const load = () => api('/audit').then(setA);
  useEffect(() => { load(); }, []);
  const scan = async () => { const r = await api('/risk/scan', { method: 'POST' }); notify(r.flagged.length ? `${r.flagged.length} project(s) newly flagged At Risk` : 'Risk scan complete — nothing new'); load(); };
  return (<><div className="between"><div><h1>Audit log</h1><p className="sub">Every automated and manual action, for transparency.</p></div><button onClick={scan}>Run risk scan</button></div>
    <div className="card"><table><thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead><tbody>
      {a.map((x) => <tr key={x.id}><td className="small">{fmtTime(x.created_at)}</td><td>{x.actor}</td><td><b>{x.action}</b></td><td>{x.entity} #{x.entity_id}</td><td className="small muted">{JSON.stringify(x.details)}</td></tr>)}</tbody></table></div></>);
}

export function Team() {
  const { user, notify } = useApp(); const [u, setU] = useState([]);
  const load = () => api('/users').then(setU);
  useEffect(() => { load(); }, []);
  const patch = async (id, body) => { try { await api(`/users/${id}`, { method: 'PATCH', body }); load(); } catch (x) { notify(x.message, true); } };
  const admin = user.role === 'admin';
  return (<><h1>Team</h1><p className="sub">Skills and capacity drive automatic task assignment.</p>
    <div className="card"><table><thead><tr><th>Name</th><th>Role</th><th>Skill</th><th>Capacity</th><th>Open tasks</th></tr></thead><tbody>
      {u.map((x) => <tr key={x.id}><td><b>{x.name}</b><div className="muted small">{x.email}</div></td>
        <td>{admin ? <select value={x.role} onChange={(e) => patch(x.id, { role: e.target.value })}>{['admin', 'manager', 'sales', 'delivery'].map((r) => <option key={r}>{r}</option>)}</select> : x.role}</td>
        <td>{admin ? <select value={x.skill} onChange={(e) => patch(x.id, { skill: e.target.value })}>{['developer', 'designer', 'qa', 'pm', 'analyst', 'general'].map((r) => <option key={r}>{r}</option>)}</select> : x.skill}</td>
        <td>{admin ? <input type="number" min="1" style={{ width: 70 }} defaultValue={x.capacity} onBlur={(e) => +e.target.value !== x.capacity && patch(x.id, { capacity: +e.target.value })} /> : x.capacity}</td>
        <td>{x.open_tasks}</td></tr>)}</tbody></table></div></>);
}

export function Templates() {
  const { notify } = useApp(); const [t, setT] = useState([]); const [edit, setEdit] = useState(null);
  const load = () => api('/templates').then(setT);
  useEffect(() => { load(); }, []);
  const save = async () => {
    try { const v = JSON.parse(edit.json); await api(`/templates/${edit.type}`, { method: 'PUT', body: { name: edit.name, duration_days: +edit.days, milestones: v } }); notify('Template saved'); setEdit(null); load(); }
    catch (x) { notify(x instanceof SyntaxError ? 'Milestones JSON is invalid' : x.message, true); }
  };
  const open = (x) => setEdit({ type: x.opportunity_type, name: x.name, days: x.duration_days, json: JSON.stringify(x.milestones, null, 2) });
  return (<><div className="between"><div><h1>Workflow templates</h1><p className="sub">Configure milestones, due-date offsets, roles and tasks generated for each deal type.</p></div>
    <button onClick={() => setEdit({ type: '', name: '', days: 30, json: '[\n  { "name": "Kickoff", "offset_days": 5, "tasks": [{ "title": "Kickoff call", "role": "pm" }] }\n]' })}>+ New template</button></div>
    {edit && <div className="card"><div className="grid g3"><div><label>Deal type key</label><input value={edit.type} onChange={(e) => setEdit({ ...edit, type: e.target.value })} /></div>
      <div><label>Name</label><input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></div>
      <div><label>Duration (days)</label><input type="number" value={edit.days} onChange={(e) => setEdit({ ...edit, days: e.target.value })} /></div></div>
      <label>Milestones (JSON)</label><textarea rows={12} style={{ fontFamily: 'monospace' }} value={edit.json} onChange={(e) => setEdit({ ...edit, json: e.target.value })} />
      <p className="row" style={{ justifyContent: 'flex-start' }}><button onClick={save}>Save</button><button className="ghost" onClick={() => setEdit(null)}>Cancel</button></p></div>}
    <div className="grid g3">{t.map((x) => <div key={x.id} className="card"><div className="between"><b>{x.name}</b><span className="badge">{x.opportunity_type}</span></div>
      <p className="muted small">{x.duration_days} days · {x.milestones.length} milestones · {x.milestones.reduce((n, m) => n + (m.tasks || []).length, 0)} tasks</p>
      <ol className="small" style={{ paddingLeft: 18 }}>{x.milestones.map((m) => <li key={m.name}>{m.name} <span className="muted">(day {m.offset_days})</span></li>)}</ol>
      <button className="ghost sm" onClick={() => open(x)}>Edit</button></div>)}</div></>);
}
