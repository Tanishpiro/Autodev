import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, money, fmtDate, fmtTime } from '../api.js';
import { useApp } from '../App.jsx';

export function Projects() {
  const [ps, setPs] = useState(null);
  useEffect(() => { api('/projects').then(setPs); }, []);
  if (!ps) return <p>Loading…</p>;
  return (
    <>
      <h1>Projects</h1><p className="sub">Created automatically from won deals.</p>
      {ps.length === 0 && <div className="card muted">No projects yet. Go to Deals and mark one as Won.</div>}
      <div className="grid g3">
        {ps.map((p) => <Link key={p.id} to={`/projects/${p.id}`} className="card" style={{ color: 'inherit' }}>
          <div className="between"><b>{p.name}</b><span className={`badge b-${p.status}`}>{p.status}</span></div>
          <p className="muted small">Manager: {p.manager_name || '—'} · Due {fmtDate(p.due_date)}</p>
          <div className={`bar ${p.status === 'At Risk' ? 'bad' : p.progress === 100 ? 'ok' : ''}`}><i style={{ width: `${p.progress}%` }} /></div>
          <div className="between small" style={{ marginTop: 6 }}><span>{p.task_done}/{p.task_total} tasks</span><span>{money(p.budget)}</span></div>
        </Link>)}
      </div>
    </>
  );
}

export function ProjectDetail() {
  const { id } = useParams(); const { notify, user, staff } = useApp();
  const [p, setP] = useState(null); const [users, setUsers] = useState([]);
  const load = () => api(`/projects/${id}`).then(setP);
  useEffect(() => { load(); api('/users').then(setUsers); }, [id]);
  if (!p) return <p>Loading…</p>;

  const upd = async (t, body) => { try { await api(`/tasks/${t.id}`, { method: 'PATCH', body }); load(); } catch (x) { notify(x.message, true); } };
  const setStatus = async (status) => { try { await api(`/projects/${p.id}`, { method: 'PATCH', body: { status } }); notify(`Project set to ${status}`); load(); } catch (x) { notify(x.message, true); } };

  return (
    <>
      <p className="small"><Link to="/projects">← Projects</Link></p>
      <div className="between"><div><h1>{p.name}</h1><p className="sub">From deal “{p.deal_title}” · Customer {p.customer_name} ({p.customer_email || 'no email'})</p></div>
        <div className="row" style={{ flex: '0 0 auto' }}><span className={`badge b-${p.status}`}>{p.status}</span>
          {staff && <select value={p.status} onChange={(e) => setStatus(e.target.value)} style={{ width: 130 }}>{['Active', 'At Risk', 'On Hold', 'Completed'].map((s) => <option key={s}>{s}</option>)}</select>}</div></div>
      <div className="grid g4">
        <div className="card kpi"><div className="l">Progress</div><div className="v">{p.progress}%</div><div className="bar"><i style={{ width: `${p.progress}%` }} /></div></div>
        <div className="card kpi"><div className="l">Budget</div><div className="v">{money(p.budget)}</div></div>
        <div className="card kpi"><div className="l">Timeline</div><div className="small">{fmtDate(p.start_date)} → {fmtDate(p.due_date)}</div></div>
        <div className="card kpi"><div className="l">Manager</div><div className="v" style={{ fontSize: 18 }}>{p.manager_name || '—'}</div></div>
      </div>
      <div className="card"><h2>Scope</h2><p style={{ margin: 0 }}>{p.scope}</p></div>
      <div className="grid g2" style={{ gridTemplateColumns: '2fr 1fr', alignItems: 'start' }}>
        <div className="card"><h2>Milestones &amp; tasks</h2>
          {p.milestones.map((m) => <div key={m.id} className={`ms ${m.status}`}>
            <div className="between"><b>{m.position}. {m.name}</b><span><span className="muted small">Due {fmtDate(m.due_date)} </span><span className={`badge b-${m.status}`}>{m.status}</span></span></div>
            <table><tbody>{p.tasks.filter((t) => t.milestone_id === m.id).map((t) => {
              const canEdit = staff || t.assignee_id === user.id;
              return <tr key={t.id}><td>{t.title}</td>
                <td style={{ width: 170 }}>{staff ? <select value={t.assignee_id || ''} onChange={(e) => upd(t, { assignee_id: +e.target.value })}><option value="" disabled>Unassigned</option>{users.filter((u) => u.active && ['delivery', 'manager'].includes(u.role)).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select> : <span className="muted">{t.assignee_name || 'Unassigned'}</span>}</td>
                <td style={{ width: 130 }}><select value={t.status} disabled={!canEdit} onChange={(e) => upd(t, { status: e.target.value })}>{['To Do', 'In Progress', 'Blocked', 'Done'].map((s) => <option key={s}>{s}</option>)}</select></td></tr>;
            })}</tbody></table></div>)}
        </div>
        <div className="card"><h2>Activity</h2>
          {p.audits.map((a) => <div key={a.id} className="note"><b className="small">{a.action}</b><div className="muted small">{a.actor} · {fmtTime(a.created_at)}</div></div>)}
        </div>
      </div>
    </>
  );
}
