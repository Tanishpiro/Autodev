import React, { useEffect, useState, createContext, useContext, useCallback } from 'react';
import { NavLink, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import { api, getToken } from './api.js';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Opportunities from './pages/Opportunities.jsx';
import { Projects, ProjectDetail } from './pages/Projects.jsx';
import { Templates, Team, Audit, Notifications } from './pages/Admin.jsx';

const Ctx = createContext();
export const useApp = () => useContext(Ctx);

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('df_user') || 'null'));
  const [toast, setToast] = useState(null);
  const [unread, setUnread] = useState(0);
  const nav = useNavigate();

  const notify = useCallback((msg, err = false) => { setToast({ msg, err }); setTimeout(() => setToast(null), 4500); }, []);
  const login = (token, u) => { localStorage.setItem('df_token', token); localStorage.setItem('df_user', JSON.stringify(u)); setUser(u); nav('/'); };
  const logout = () => { localStorage.removeItem('df_token'); localStorage.removeItem('df_user'); setUser(null); nav('/login'); };

  useEffect(() => {
    if (!user) return;
    const load = () => api('/notifications').then((n) => setUnread(n.filter((x) => !x.read).length)).catch(() => {});
    load(); const t = setInterval(load, 15000); return () => clearInterval(t);
  }, [user]);

  if (!user || !getToken()) {
    return <Ctx.Provider value={{ notify, login }}><Routes><Route path="*" element={<Login />} /></Routes>{toast && <div className={`toast ${toast.err ? 'err' : ''}`}>{toast.msg}</div>}</Ctx.Provider>;
  }
  const staff = ['admin', 'manager'].includes(user.role);
  return (
    <Ctx.Provider value={{ user, notify, staff, setUnread }}>
      <div className="shell">
        <aside className="side">
          <div className="logo">⚡ DeliveryFlow</div>
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/opportunities">Deals (CRM)</NavLink>
          <NavLink to="/projects">Projects</NavLink>
          <NavLink to="/notifications">Notifications {unread > 0 && <span className="pill">{unread}</span>}</NavLink>
          {staff && <NavLink to="/audit">Audit log</NavLink>}
          <NavLink to="/team">Team</NavLink>
          {user.role === 'admin' && <NavLink to="/templates">Workflow templates</NavLink>}
          <div className="user">{user.name}<br /><span className="muted">{user.role}</span><br /><a href="#" onClick={(e) => { e.preventDefault(); logout(); }}>Sign out</a></div>
        </aside>
        <main className="main">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/opportunities" element={<Opportunities />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/projects/:id" element={<ProjectDetail />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/audit" element={staff ? <Audit /> : <Navigate to="/" />} />
            <Route path="/team" element={<Team />} />
            <Route path="/templates" element={user.role === 'admin' ? <Templates /> : <Navigate to="/" />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
      {toast && <div className={`toast ${toast.err ? 'err' : ''}`}>{toast.msg}</div>}
    </Ctx.Provider>
  );
}
